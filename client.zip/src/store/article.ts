// // @ts-ignore
// import { defineStore } from 'pinia';
// // @ts-ignore
// import createPersistedState from 'pinia-plugin-persistedstate';
//
// export const useArticleStore = defineStore('article', {
//   plugins: [createPersistedState()],
//   state: () => ({
//     id: '',
//     filepath: '',
//     title: '',
//   }),
//   actions: {
//     setId(id: string) {
//       this.id = id;
//     },
//     setFilepath(filepath: string) {
//       this.filepath = filepath;
//     },
//     setTitle(title: string) {
//       this.title = title;
//     },
//   },
//   getters: {
//     getId() {
//       return this.id;
//     },
//     getFilepath() {
//       return this.filepath;
//     },
//     getTitle() {
//       return this.title;
//     },
//   }
// });
