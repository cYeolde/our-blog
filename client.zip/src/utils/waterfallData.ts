export default [
  {
    url: 'https://images.pexels.com/photos/4737484/pexels-photo-4737484.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    width: 4288,
    height: 2848
  },
  {
    url: 'https://images.pexels.com/photos/3052361/pexels-photo-3052361.jpeg?auto=compress&cs=tinysrgb&w=1600&lazy=load',
    width: 3843,
    height: 5790
  },
  {
    url: 'https://images.pexels.com/photos/3293148/pexels-photo-3293148.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    width: 5832,
    height: 3888
  },
  {
    url: 'https://images.pexels.com/photos/3565742/pexels-photo-3565742.jpeg?auto=compress&cs=tinysrgb&w=1600&lazy=load',
    width: 4000,
    height: 6000
  },
  {
    url: 'https://images.pexels.com/photos/1049298/pexels-photo-1049298.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    width: 6016,
    height: 4000
  },
  {
    url: 'https://images.pexels.com/photos/3538659/pexels-photo-3538659.jpeg?auto=compress&cs=tinysrgb&w=1600&lazy=load',
    width: 3959,
    height: 5938
  },
  {
    url: 'https://images.pexels.com/photos/1181340/pexels-photo-1181340.jpeg?auto=compress&cs=tinysrgb&w=1600&lazy=load',
    width: 3024,
    height: 4032
  },
  {
    url: 'https://images.pexels.com/photos/2931915/pexels-photo-2931915.jpeg?auto=compress&cs=tinysrgb&w=1600&lazy=load',
    width: 3456,
    height: 5184
  },
  {
    url: 'https://images.pexels.com/photos/3538721/pexels-photo-3538721.jpeg?auto=compress&cs=tinysrgb&w=1600&lazy=load',
    width: 3922,
    height: 5883
  },
  {
    url: 'https://images.pexels.com/photos/1142941/pexels-photo-1142941.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    width: 4877,
    height: 7736
  }
]
