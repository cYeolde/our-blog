<script setup lang="ts">
import TagsList from "@/components/Tags/TagsList.vue";
</script>

<template>
  <TagsList />
<!--  <img :src="util.getAssetsFile('Archive/ArchiveCarousel1.jpg')" alt="">-->
</template>

<style scoped>

</style>
