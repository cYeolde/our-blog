<template>
  <div>
    <todoList />
  </div>
  <div id="gitalk-container"></div>
</template>

<script setup lang="ts">
import todoList from "@/components/About/todoList.vue";
import 'gitalk/dist/gitalk.css'
import Gitalk from 'gitalk'


</script>

<style scoped>

</style>


