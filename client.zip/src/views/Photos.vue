<template>
  <div>
    <Waterfall/>
  </div>
</template>

<script setup lang="ts">
import Waterfall from "@/components/Photos/Waterfall.vue";


</script>

<style scoped>

</style>



