<template>
  <ArchiveCarousel />
  <ArchiveCard />
</template>

<script setup lang="ts">
import ArchiveCarousel from "@/components/Archive/ArchiveCarousel.vue";
import ArchiveCard from "@/components/Archive/ArchiveCard.vue";
</script>


<style scoped>


</style>
