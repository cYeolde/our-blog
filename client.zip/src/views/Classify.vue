<template>
  <div>
    <router-view />
  </div>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>
